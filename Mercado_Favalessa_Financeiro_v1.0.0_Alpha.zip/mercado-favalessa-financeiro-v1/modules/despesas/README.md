# Módulo despesas

Implementação integrada nesta versão Alpha.
