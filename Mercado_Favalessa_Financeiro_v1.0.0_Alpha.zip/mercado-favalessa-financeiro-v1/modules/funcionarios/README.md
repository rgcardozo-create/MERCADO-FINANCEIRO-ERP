# Módulo funcionarios

Implementação integrada nesta versão Alpha.
