# Módulo configuracoes

Implementação integrada nesta versão Alpha.
