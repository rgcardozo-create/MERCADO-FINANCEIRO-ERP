# Módulo contas-pagar

Implementação integrada nesta versão Alpha.
