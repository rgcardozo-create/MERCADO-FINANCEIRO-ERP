# Módulo livro-caixa

Implementação integrada nesta versão Alpha.
