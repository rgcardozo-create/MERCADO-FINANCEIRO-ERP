# Módulo fluxo-caixa

Implementação integrada nesta versão Alpha.
