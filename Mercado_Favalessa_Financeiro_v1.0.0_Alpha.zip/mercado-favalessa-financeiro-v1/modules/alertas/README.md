# Módulo alertas

Implementação integrada nesta versão Alpha.
