# Módulo indicadores

Implementação integrada nesta versão Alpha.
