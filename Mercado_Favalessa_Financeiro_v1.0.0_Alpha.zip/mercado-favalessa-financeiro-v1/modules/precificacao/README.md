# Módulo precificacao

Implementação integrada nesta versão Alpha.
