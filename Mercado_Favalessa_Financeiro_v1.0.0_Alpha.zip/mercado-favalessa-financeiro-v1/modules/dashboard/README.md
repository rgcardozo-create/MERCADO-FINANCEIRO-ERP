# Módulo dashboard

Implementação integrada nesta versão Alpha.
