# Módulo venda-prazo

Implementação integrada nesta versão Alpha.
