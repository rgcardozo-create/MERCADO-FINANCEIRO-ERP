export function money(v){return Number(v||0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"})}
export function today(){return new Date().toISOString().slice(0,10)}
export function uid(){return "id_"+Math.random().toString(36).slice(2)+Date.now().toString(36)}
