# Mercado Favalessa Financeiro

Versão 1.0.0 Alpha.

Sistema financeiro simples, sem banco externo e sem mensalidade.

## Publicação
1. Extraia o ZIP.
2. Envie os arquivos para o GitHub.
3. Publique na Vercel como projeto estático.

## Armazenamento
Os dados ficam no navegador via LocalStorage. Use Configurações > Exportar Backup.

## Regra principal
Recebimentos de venda a prazo entram apenas como Recebimento de Venda a Prazo. A forma de pagamento fica somente no histórico do cliente.
